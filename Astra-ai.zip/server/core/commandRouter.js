const tools = require('../tools/toolsRegistry');

async function routeCommand(input) {

    if (input.includes("time")) {
        return tools.time.execute();
    }

    return "Command not understood.";
}

module.exports = routeCommand;